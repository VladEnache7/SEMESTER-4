﻿export interface News {
  NewsTitle: string;
  NewsId: number;
  NewsProducer: string;
  NewsDatePosted: string;
  NewsCategory: string;
  NewsContent: string;
}

